// const maincontactAddress = "0xd80692965016dfd893b07b1bf1b9d3289326b7b9";
// const maincontactAddress = "0xd1F6b92510e3614d4d6c1B30b6084fd452cc74d3"
const tokenContractAddress = "0x959b88966fC5B261dF8359961357d34F4ee27b4a"
const NFTContractAdress = "0x89323f00a621D4eD6A56a93295C5f10f4df57FFa";

const http = "https://api.avax.network/ext/bc/C/rpc";
const chainId = 43114;
const chainHex = '0xA86A';
export {
  tokenContractAddress,
  http,
  chainId,
  chainHex,
  NFTContractAdress
};